ToPy was part of my MScEng degree at the University of Stellenbosch,
South Africa. It is really a prototype software - if you can improve
it in any way, go ahead.

You're welcome to e-mail me with any questions and/or comments. I'll
do my best to respond in a reasonable time, just be patient as I
have a 'real' job during the day and I'm not actively working on
ToPy any more. 

If you do use it in your research, please acknowledge me where you
think it's necessary.
--
William Hunter
willemjagter@gmail.com
26-01-2010