Simple tests to check the assembly of finite elements.

===========================
=== To run the programs ===
===========================
In a terminal, type:
python test_<dimension>_elem.py <elementname>.tpd

For example, to test the 3D Hex 8 (H8) element, do:
python test_3D_elem.py H8.tpd
